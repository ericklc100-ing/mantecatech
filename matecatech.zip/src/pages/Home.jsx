import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import ProductCard from '../components/ui/ProductCard'
import { Tv, Trophy, Zap, Star } from 'lucide-react'
import { Link } from 'react-router-dom'
import styles from './Home.module.css'

export default function Home() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('products')
      .select('*')
      .gt('stock', 0)
      .order('destacado', { ascending: false })
      .limit(6)
      .then(({ data }) => {
        setProducts(data || [])
        setLoading(false)
      })
  }, [])

  return (
    <div>
      {/* HERO */}
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <div className={styles.heroBadge}>
              <Trophy size={14} />
              FIFA World Cup 2026™
            </div>
            <h1 className={styles.heroTitle}>
              VIVÍ EL<br />
              <span className={styles.heroGold}>MUNDIAL</span><br />
              EN GRANDE
            </h1>
            <p className={styles.heroSub}>
              Smart TVs de última generación con precios imbatibles. Lomas del Mirador y todo el GBA.
            </p>
            <div className={styles.heroActions}>
              <Link to="/productos" className="btn btn-gold">
                <Tv size={18} /> Ver Smart TVs
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <div className={styles.tvFrame}>
              <div className={styles.tvScreen}>
                <div className={styles.tvContent}>
                  <div className={styles.tvScore}>
                    <span>ARG</span>
                    <span className={styles.tvScoreNum}>2 — 1</span>
                    <span>BRA</span>
                  </div>
                  <div className={styles.tvBadge}>4K ULTRA HD</div>
                </div>
              </div>
              <div className={styles.tvBase} />
            </div>
          </div>
        </div>
        <div className={styles.heroWave} />
      </section>

      {/* FEATURES */}
      <section className={styles.features}>
        <div className="container">
          <div className={styles.featureGrid}>
            {[
              { icon: <Zap size={24} />, title: 'Entrega Rápida', desc: 'Envíos a todo el GBA y CABA' },
              { icon: <Star size={24} />, title: 'Garantía Oficial', desc: '12 meses en todos los productos' },
              { icon: <Trophy size={24} />, title: 'Precio Mundial', desc: 'Las mejores ofertas del mercado' },
            ].map((f, i) => (
              <div key={i} className={styles.featureItem}>
                <div className={styles.featureIcon}>{f.icon}</div>
                <div>
                  <div className={styles.featureTitle}>{f.title}</div>
                  <div className={styles.featureDesc}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCTOS DESTACADOS */}
      <section className={styles.productsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="page-title">DESTACADOS</h2>
            <Link to="/productos" className="btn btn-outline">Ver todos →</Link>
          </div>
          {loading
            ? <div className="spinner" />
            : <div className="products-grid">
                {products.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
          }
        </div>
      </section>

      {/* BANNER MUNDIAL */}
      <section className={styles.worldcupBanner}>
        <div className="container">
          <div className={styles.bannerInner}>
            <div>
              <h2 className={styles.bannerTitle}>FALTAN POCOS DÍAS<br />¿TU TV ESTÁ LISTA?</h2>
              <p className={styles.bannerSub}>Llevate la tuya con envío express al GBA</p>
            </div>
            <Link to="/productos" className="btn btn-gold">
              <Trophy size={18} /> Ver ofertas mundialistas
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className={styles.footer}>
        <div className="container">
          <div className={styles.footerInner}>
            <div>
              <div className={styles.footerLogo}>MatecaTech</div>
              <p className={styles.footerSub}>Smart TVs · Lomas del Mirador, GBA</p>
            </div>
            <div className={styles.footerLinks}>
              <Link to="/productos">Productos</Link>
              <Link to="/login">Ingresar</Link>
              <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER || '5491100000000'}`} target="_blank" rel="noreferrer">WhatsApp</a>
            </div>
          </div>
          <p className={styles.footerCopy}>© 2026 MatecaTech. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
