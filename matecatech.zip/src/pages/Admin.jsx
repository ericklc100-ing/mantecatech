import { useEffect, useState, useRef } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'
import toast from 'react-hot-toast'
import {
  Package, ShoppingBag, Settings, Plus, Edit2, Trash2,
  Check, X, Upload, Save, Loader
} from 'lucide-react'
import styles from './Admin.module.css'

export default function Admin() {
  const { user, profile, isAdmin, loading } = useAuth()
  const [tab, setTab] = useState('products')

  if (loading) return <div className="spinner" />
  if (!user || !isAdmin) return <Navigate to="/" />

  return (
    <div className={styles.page}>
      <div className="container">
        <div className={styles.pageHeader}>
          <h1 className="page-title">PANEL ADMIN</h1>
          <span className="badge badge-red">🔒 Solo administradores</span>
        </div>

        <div className={styles.tabs}>
          {[
            { key: 'products', icon: <Package size={16} />, label: 'Inventario' },
            { key: 'orders', icon: <ShoppingBag size={16} />, label: 'Pedidos' },
            { key: 'config', icon: <Settings size={16} />, label: 'Configuración Envío' },
          ].map(t => (
            <button key={t.key} className={`${styles.tab} ${tab === t.key ? styles.tabActive : ''}`} onClick={() => setTab(t.key)}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {tab === 'products' && <ProductsAdmin />}
        {tab === 'orders' && <OrdersAdmin />}
        {tab === 'config' && <ShippingConfig />}
      </div>
    </div>
  )
}

// ─── PRODUCTS CRUD ─────────────────────────────────────────────────────────

function ProductsAdmin() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [editId, setEditId] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const emptyForm = { nombre: '', descripcion: '', precio: '', stock: '', resolucion: '', sistema_operativo: '', marca: '', pulgadas: '', destacado: false, badge: '', imagen_url: '' }
  const [form, setForm] = useState(emptyForm)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()

  useEffect(() => { fetchProducts() }, [])

  async function fetchProducts() {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false })
    setProducts(data || [])
    setLoading(false)
  }

  function openCreate() { setForm(emptyForm); setEditId(null); setShowForm(true) }
  function openEdit(p) {
    setForm({ ...p, precio: p.precio.toString(), stock: p.stock.toString(), pulgadas: p.pulgadas?.toString() || '' })
    setEditId(p.id)
    setShowForm(true)
  }

  async function handleImageUpload(e) {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    const ext = file.name.split('.').pop()
    const filename = `product-${Date.now()}.${ext}`
    const { data, error } = await supabase.storage.from('product-images').upload(filename, file)
    if (error) { toast.error('Error al subir imagen: ' + error.message); setUploading(false); return }
    const { data: { publicUrl } } = supabase.storage.from('product-images').getPublicUrl(filename)
    setForm(f => ({ ...f, imagen_url: publicUrl }))
    setUploading(false)
    toast.success('Imagen subida ✓')
  }

  async function handleSave() {
    const payload = {
      ...form,
      precio: parseFloat(form.precio),
      stock: parseInt(form.stock),
      pulgadas: form.pulgadas ? parseInt(form.pulgadas) : null,
    }
    if (!payload.nombre || !payload.precio || !payload.stock) { toast.error('Nombre, precio y stock son requeridos'); return }

    if (editId) {
      const { error } = await supabase.from('products').update(payload).eq('id', editId)
      if (error) toast.error(error.message)
      else { toast.success('Producto actualizado ✓'); setShowForm(false); fetchProducts() }
    } else {
      const { error } = await supabase.from('products').insert(payload)
      if (error) toast.error(error.message)
      else { toast.success('Producto creado ✓'); setShowForm(false); fetchProducts() }
    }
  }

  async function handleDelete(id) {
    if (!confirm('¿Eliminar este producto?')) return
    const { error } = await supabase.from('products').delete().eq('id', id)
    if (error) toast.error(error.message)
    else { toast.success('Eliminado'); fetchProducts() }
  }

  return (
    <div className={styles.section}>
      <div className={styles.sectionHeader}>
        <h2 className="section-title">Inventario</h2>
        <button className="btn btn-gold" onClick={openCreate}><Plus size={16} /> Nuevo Producto</button>
      </div>

      {showForm && (
        <div className={styles.formCard}>
          <h3 className={styles.formTitle}>{editId ? 'Editar Producto' : 'Nuevo Producto'}</h3>
          <div className={styles.formGrid}>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Nombre</label>
              <input value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} placeholder="Samsung 4K 55&quot;" />
            </div>
            <div className="form-group">
              <label>Marca</label>
              <input value={form.marca} onChange={e => setForm(f => ({ ...f, marca: e.target.value }))} placeholder="Samsung" />
            </div>
            <div className="form-group">
              <label>Pulgadas</label>
              <input type="number" value={form.pulgadas} onChange={e => setForm(f => ({ ...f, pulgadas: e.target.value }))} placeholder="55" />
            </div>
            <div className="form-group">
              <label>Precio ($)</label>
              <input type="number" value={form.precio} onChange={e => setForm(f => ({ ...f, precio: e.target.value }))} placeholder="289999" />
            </div>
            <div className="form-group">
              <label>Stock</label>
              <input type="number" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} placeholder="10" />
            </div>
            <div className="form-group">
              <label>Resolución</label>
              <input value={form.resolucion} onChange={e => setForm(f => ({ ...f, resolucion: e.target.value }))} placeholder="4K UHD" />
            </div>
            <div className="form-group">
              <label>Sistema Operativo</label>
              <input value={form.sistema_operativo} onChange={e => setForm(f => ({ ...f, sistema_operativo: e.target.value }))} placeholder="Android TV 13" />
            </div>
            <div className="form-group">
              <label>Badge</label>
              <select value={form.badge} onChange={e => setForm(f => ({ ...f, badge: e.target.value }))}>
                <option value="">Sin badge</option>
                <option>Precio Mundial</option>
                <option>Premium</option>
                <option>Más Vendido</option>
                <option>Top de Línea</option>
                <option>Oferta</option>
              </select>
            </div>
            <div className="form-group" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexDirection: 'row', paddingTop: '1.5rem' }}>
              <input type="checkbox" id="dest" checked={form.destacado} onChange={e => setForm(f => ({ ...f, destacado: e.target.checked }))} style={{ width: 'auto' }} />
              <label htmlFor="dest" style={{ margin: 0 }}>Destacado</label>
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Descripción</label>
              <textarea rows={2} value={form.descripcion} onChange={e => setForm(f => ({ ...f, descripcion: e.target.value }))} style={{ resize: 'vertical', padding: '0.75rem', border: '2px solid var(--gris-medio)', borderRadius: '6px' }} />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Imagen</label>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
                <input value={form.imagen_url} onChange={e => setForm(f => ({ ...f, imagen_url: e.target.value }))} placeholder="URL de imagen o sube un archivo" style={{ flex: 1 }} />
                <button type="button" className="btn btn-outline" onClick={() => fileRef.current.click()} disabled={uploading}>
                  {uploading ? <Loader size={15} className={styles.spin} /> : <Upload size={15} />} Subir
                </button>
                <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleImageUpload} />
              </div>
              {form.imagen_url && <img src={form.imagen_url} alt="preview" style={{ width: 80, height: 50, objectFit: 'cover', borderRadius: 4, marginTop: '0.5rem' }} />}
            </div>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.5rem' }}>
            <button className="btn btn-primary" onClick={handleSave}><Save size={15} /> Guardar</button>
            <button className="btn btn-outline" onClick={() => setShowForm(false)}><X size={15} /> Cancelar</button>
          </div>
        </div>
      )}

      {loading ? <div className="spinner" /> : (
        <div className="table-wrapper">
          <table>
            <thead><tr><th>Imagen</th><th>Nombre</th><th>Precio</th><th>Stock</th><th>Resolución</th><th>S.O.</th><th>Acciones</th></tr></thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id}>
                  <td>
                    {p.imagen_url
                      ? <img src={p.imagen_url} alt={p.nombre} style={{ width: 56, height: 36, objectFit: 'cover', borderRadius: 4 }} />
                      : <span>📺</span>}
                  </td>
                  <td><strong>{p.nombre}</strong></td>
                  <td>${p.precio.toLocaleString('es-AR')}</td>
                  <td>
                    <span className={p.stock <= 0 ? 'badge badge-red' : p.stock <= 5 ? 'badge badge-gold' : 'badge badge-green'}>
                      {p.stock}
                    </span>
                  </td>
                  <td>{p.resolucion}</td>
                  <td>{p.sistema_operativo}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '0.4rem' }}>
                      <button className="btn btn-outline" style={{ padding: '0.3rem 0.6rem' }} onClick={() => openEdit(p)}><Edit2 size={14} /></button>
                      <button className="btn btn-danger" style={{ padding: '0.3rem 0.6rem' }} onClick={() => handleDelete(p.id)}><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ─── ORDERS ────────────────────────────────────────────────────────────────

function OrdersAdmin() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('Pendiente')

  useEffect(() => { fetchOrders() }, [filter])

  async function fetchOrders() {
    let q = supabase.from('orders').select('*').order('created_at', { ascending: false })
    if (filter !== 'Todos') q = q.eq('estado', filter)
    const { data } = await q
    setOrders(data || [])
    setLoading(false)
  }

  async function handleFinalize(id) {
    const { error } = await supabase.from('orders').update({ estado: 'Finalizado', updated_at: new Date().toISOString() }).eq('id', id)
    if (error) toast.error(error.message)
    else { toast.success('Pedido finalizado ✓'); fetchOrders() }
  }

  async function handleCancel(id) {
    if (!confirm('¿Cancelar este pedido?')) return
    const { error } = await supabase.from('orders').update({ estado: 'Cancelado' }).eq('id', id)
    if (error) toast.error(error.message)
    else { toast.success('Pedido cancelado'); fetchOrders() }
  }

  return (
    <div className={styles.section}>
      <div className={styles.sectionHeader}>
        <h2 className="section-title">Pedidos</h2>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {['Todos', 'Pendiente', 'Finalizado', 'Cancelado'].map(s => (
            <button key={s} className={`btn ${filter === s ? 'btn-primary' : 'btn-outline'}`} style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem' }} onClick={() => setFilter(s)}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {loading ? <div className="spinner" /> : (
        <div className="table-wrapper">
          <table>
            <thead><tr><th>ID</th><th>Fecha</th><th>Dirección</th><th>Items</th><th>Envío</th><th>Total</th><th>Estado</th><th>Acciones</th></tr></thead>
            <tbody>
              {orders.map(o => (
                <tr key={o.id}>
                  <td><code className={styles.orderId}>#{o.id.slice(-8).toUpperCase()}</code></td>
                  <td style={{ fontSize: '0.85rem' }}>{new Date(o.created_at).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' })}</td>
                  <td style={{ maxWidth: 150, fontSize: '0.85rem' }}>{o.direccion_entrega}</td>
                  <td>
                    <ul className={styles.orderItems}>
                      {o.detalles_carrito?.map((item, i) => <li key={i}>{item.cantidad}x {item.nombre}</li>)}
                    </ul>
                  </td>
                  <td>${o.costo_envio?.toLocaleString('es-AR')}</td>
                  <td><strong>${o.total?.toLocaleString('es-AR')}</strong></td>
                  <td>
                    <span className={`badge ${o.estado === 'Finalizado' ? 'badge-green' : o.estado === 'Cancelado' ? 'badge-red' : 'badge-gold'}`}>
                      {o.estado}
                    </span>
                  </td>
                  <td>
                    {o.estado === 'Pendiente' && (
                      <div style={{ display: 'flex', gap: '0.4rem' }}>
                        <button className="btn btn-green" style={{ padding: '0.3rem 0.6rem', fontSize: '0.8rem' }} onClick={() => handleFinalize(o.id)}>
                          <Check size={14} /> Finalizar
                        </button>
                        <button className="btn btn-danger" style={{ padding: '0.3rem 0.6rem' }} onClick={() => handleCancel(o.id)}>
                          <X size={14} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {orders.length === 0 && <p style={{ textAlign: 'center', padding: '2rem', color: 'var(--gris-texto)' }}>No hay pedidos con este estado</p>}
        </div>
      )}
    </div>
  )
}

// ─── SHIPPING CONFIG ────────────────────────────────────────────────────────

function ShippingConfig() {
  const [config, setConfig] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    supabase.from('config_envio').select('*').eq('id', 1).single()
      .then(({ data }) => { setConfig(data); setLoading(false) })
  }, [])

  async function handleSave(e) {
    e.preventDefault()
    setSaving(true)
    const { error } = await supabase.from('config_envio').update({
      precio_por_km: parseFloat(config.precio_por_km),
      radio_bonificacion: parseInt(config.radio_bonificacion),
      monto_bonificacion: parseFloat(config.monto_bonificacion),
      envio_gratis_minimo: parseFloat(config.envio_gratis_minimo),
      cp_validos: config.cp_validos,
      updated_at: new Date().toISOString()
    }).eq('id', 1)
    if (error) toast.error(error.message)
    else toast.success('Configuración guardada ✓')
    setSaving(false)
  }

  if (loading) return <div className="spinner" />

  return (
    <div className={styles.section}>
      <div className={styles.sectionHeader}>
        <h2 className="section-title">Configuración de Envío</h2>
      </div>
      <div className={styles.configCard}>
        <form onSubmit={handleSave}>
          <div className={styles.configGrid}>
            <div className="form-group">
              <label>Precio por KM ($)</label>
              <input type="number" value={config?.precio_por_km || ''} onChange={e => setConfig(c => ({ ...c, precio_por_km: e.target.value }))} step="0.01" />
              <small>Tarifa base por kilómetro de distancia</small>
            </div>
            <div className="form-group">
              <label>Radio de Bonificación (km)</label>
              <input type="number" value={config?.radio_bonificacion || ''} onChange={e => setConfig(c => ({ ...c, radio_bonificacion: e.target.value }))} />
              <small>Distancia máxima para aplicar bonificación</small>
            </div>
            <div className="form-group">
              <label>Monto de Bonificación ($)</label>
              <input type="number" value={config?.monto_bonificacion || ''} onChange={e => setConfig(c => ({ ...c, monto_bonificacion: e.target.value }))} step="0.01" />
              <small>Descuento aplicado en zona bonificada</small>
            </div>
            <div className="form-group">
              <label>Envío gratis desde ($)</label>
              <input type="number" value={config?.envio_gratis_minimo || ''} onChange={e => setConfig(c => ({ ...c, envio_gratis_minimo: e.target.value }))} step="0.01" />
              <small>Monto mínimo para envío gratuito</small>
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Códigos Postales CABA (separados por coma)</label>
              <input
                value={config?.cp_validos?.join(', ') || ''}
                onChange={e => setConfig(c => ({ ...c, cp_validos: e.target.value.split(',').map(v => v.trim()).filter(Boolean) }))}
                placeholder="1000, 1001, 1437, ..."
              />
              <small>CPs que reciben bonificación de CABA</small>
            </div>
          </div>

          <div className={styles.configPreview}>
            <h4>Vista previa de cálculo</h4>
            <p>🏠 Origen: Lomas del Mirador, GBA</p>
            <p>📍 Dentro de {config?.radio_bonificacion} km → Descuento de ${parseFloat(config?.monto_bonificacion || 0).toLocaleString('es-AR')}</p>
            <p>🚚 Por km adicional → ${parseFloat(config?.precio_por_km || 0).toLocaleString('es-AR')}/km</p>
            <p>🎁 Envío gratis en compras mayores a ${parseFloat(config?.envio_gratis_minimo || 0).toLocaleString('es-AR')}</p>
          </div>

          <button type="submit" className="btn btn-primary" disabled={saving}>
            <Save size={16} /> {saving ? 'Guardando...' : 'Guardar Configuración'}
          </button>
        </form>
      </div>
    </div>
  )
}
