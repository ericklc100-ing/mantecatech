import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ShoppingCart, User, LogOut, Settings, Menu, X, Tv } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'
import { useCart } from '../../context/CartContext'
import styles from './Navbar.module.css'

export default function Navbar({ onCartOpen }) {
  const { user, profile, signOut, isAdmin } = useAuth()
  const { totalItems } = useCart()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  async function handleSignOut() {
    await signOut()
    navigate('/')
    setUserMenuOpen(false)
  }

  return (
    <nav className={styles.navbar}>
      <div className={`container ${styles.inner}`}>
        {/* Logo */}
        <Link to="/" className={styles.logo}>
          <Tv size={26} className={styles.logoIcon} />
          <span className={styles.logoText}>MatecaTech</span>
          <span className={styles.logoBadge}>Mundial 2026</span>
        </Link>

        {/* Desktop Nav */}
        <div className={styles.desktopNav}>
          <Link to="/" className={styles.navLink}>Inicio</Link>
          <Link to="/productos" className={styles.navLink}>Smart TVs</Link>
        </div>

        {/* Actions */}
        <div className={styles.actions}>
          {/* Cart Button */}
          <button className={styles.cartBtn} onClick={onCartOpen} aria-label="Carrito">
            <ShoppingCart size={22} />
            {totalItems > 0 && (
              <span className={styles.cartBadge}>{totalItems}</span>
            )}
          </button>

          {/* User */}
          {user ? (
            <div className={styles.userMenu}>
              <button className={styles.userBtn} onClick={() => setUserMenuOpen(!userMenuOpen)}>
                <div className={styles.avatar}>
                  {(profile?.nombre || user.email)[0].toUpperCase()}
                </div>
              </button>
              {userMenuOpen && (
                <div className={styles.dropdown}>
                  <div className={styles.dropdownHeader}>
                    <span className={styles.dropdownName}>{profile?.nombre || 'Usuario'}</span>
                    <span className={styles.dropdownEmail}>{user.email}</span>
                  </div>
                  <Link to="/perfil" className={styles.dropdownItem} onClick={() => setUserMenuOpen(false)}>
                    <User size={16} /> Mi Perfil
                  </Link>
                  {isAdmin && (
                    <Link to="/admin" className={styles.dropdownItem} onClick={() => setUserMenuOpen(false)}>
                      <Settings size={16} /> Panel Admin
                    </Link>
                  )}
                  <button className={`${styles.dropdownItem} ${styles.dropdownLogout}`} onClick={handleSignOut}>
                    <LogOut size={16} /> Cerrar sesión
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className={`btn btn-primary ${styles.loginBtn}`}>
              <User size={16} /> Ingresar
            </Link>
          )}

          {/* Mobile menu toggle */}
          <button className={styles.menuToggle} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {menuOpen && (
        <div className={styles.mobileNav}>
          <Link to="/" onClick={() => setMenuOpen(false)}>Inicio</Link>
          <Link to="/productos" onClick={() => setMenuOpen(false)}>Smart TVs</Link>
          {user && <Link to="/perfil" onClick={() => setMenuOpen(false)}>Mi Perfil</Link>}
          {isAdmin && <Link to="/admin" onClick={() => setMenuOpen(false)}>Admin</Link>}
          {!user && <Link to="/login" onClick={() => setMenuOpen(false)}>Ingresar</Link>}
        </div>
      )}
    </nav>
  )
}
